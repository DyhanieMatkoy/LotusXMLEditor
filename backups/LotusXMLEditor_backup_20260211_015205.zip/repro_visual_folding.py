
import sys
from PyQt6.QtWidgets import QApplication, QTextEdit
from PyQt6.QtGui import QFont
from main import XmlEditorWidget, MainWindow

def test_visual_folding():
    app = QApplication(sys.argv)
    
    editor = XmlEditorWidget()
    editor.set_line_numbers_visible(True)
    
    # Case 1: XML with // in text content
    xml_content = """<root>
    <path>C://Program Files//App</path>
    <url>http://example.com</url>
    <comment>
        // This is a comment style text
        // Another line
    </comment>
</root>"""
    
    editor.set_content(xml_content)
    editor.resize(800, 600)
    editor.show()
    
    # Simulate finding range at line 4 (<comment>)
    # Line 4 is index 3 (0-based)
    # <comment> starts at index ... let's find it
    
    print("Content set.")
    
    # Mock MainWindow for _compute_range_lines_at_cursor
    mw = MainWindow()
    mw.xml_editor = editor
    
    # Move cursor to line 4
    cursor = editor.textCursor()
    cursor.movePosition(cursor.MoveOperation.Start)
    for _ in range(3): # Move down 3 times to get to line 4
        cursor.movePosition(cursor.MoveOperation.Down)
    # Move to end of line to ensure we are inside the tag
    cursor.movePosition(cursor.MoveOperation.EndOfBlock)
    editor.setTextCursor(cursor)
    
    print(f"Cursor at line: {cursor.blockNumber() + 1}")
    
    # Compute range
    print("DEBUG: Calling _compute_enclosing_xml_ranges...")
    all_ranges = mw._compute_enclosing_xml_ranges(xml_content)
    print(f"DEBUG: All ranges found: {all_ranges}")
    
    rng = mw._compute_range_lines_at_cursor()
    print(f"Computed range: {rng}")
    
    if rng:
        print(f"Folding lines {rng[0]} to {rng[1]}...")
        editor.fold_lines(rng[0], rng[1])
        
        # Check _folded_ranges
        print(f"_folded_ranges: {editor._folded_ranges}")
        
        # Check block visibility
        doc = editor.document()
        # Line 4 (start) should be visible
        blk4 = doc.findBlockByNumber(3)
        print(f"Line 4 visible: {blk4.isVisible()}")
        
        # Line 5 (inner) should be hidden
        blk5 = doc.findBlockByNumber(4)
        print(f"Line 5 visible: {blk5.isVisible()}")
        
        # Line 7 (end) should be visible?
        # Range is inclusive start/end.
        # fold_lines hides "inner lines between start and end".
        # If range is (4, 7).
        # Inner is 5, 6.
        blk7 = doc.findBlockByNumber(6)
        print(f"Line 7 visible: {blk7.isVisible()}")
        
        # Check if fold indicator would be drawn
        # LineNumberWidget checks: line_number in folded_starts
        folded_starts = {r[0] for r in editor._folded_ranges}
        print(f"Folded starts: {folded_starts}")
        print(f"Is line 4 in folded_starts? {4 in folded_starts}")

    # Case 2: Edit text to trigger auto-unfold
    print("\nEditing text...")
    cursor.insertText("Changed ")
    
    # Check if unfolded
    print(f"_folded_ranges after edit: {editor._folded_ranges}")
    blk5 = doc.findBlockByNumber(4)
    print(f"Line 5 visible after edit: {blk5.isVisible()}")

    # Case 3: Reproduce "Hidden but no indicator" state
    print("\nCase 3: Simulating state desync...")
    # Manually hide lines 5-6 but clear _folded_ranges
    editor.fold_lines(4, 7) # Folds 4-7 (hides 5-6)
    print("Folded 4-7. _folded_ranges:", editor._folded_ranges)
    
    # Force clear _folded_ranges without unfolding
    editor._folded_ranges = [] 
    print("Cleared _folded_ranges manually.")
    
    # Now line 4 should be visible, 5-6 hidden, 7 visible.
    # But line 4 should NOT have a triangle in paintEvent because it's not in folded_starts.
    
    blk4 = doc.findBlockByNumber(3)
    blk5 = doc.findBlockByNumber(4)
    print(f"Line 4 visible: {blk4.isVisible()}")
    print(f"Line 5 visible: {blk5.isVisible()}")
    
    folded_starts = {r[0] for r in editor._folded_ranges}
    print(f"Is line 4 in folded_starts? {4 in folded_starts}")
    
    # This confirms that IF _folded_ranges is empty but lines are hidden, we get the bug.
    # Now, how can this happen naturally?
    
    # Hypothesis: Exception in unfold_all?
    # Let's try to mock an exception in setVisible
    print("\nTesting exception resilience in unfold_all...")
    
    # Reset
    editor.unfold_all()
    editor.fold_lines(4, 7)
    
    # Mock setVisible to raise exception for line 5
    original_setVisible = None
    # We can't easily mock QTextBlock.setVisible because it's a C++ wrapper.
    # But we can try to find a scenario where it fails.
    
    # What if we delete the text containing the hidden lines?
    # If we select lines 4-7 and delete them?
    print("Deleting folded lines...")
    cursor.setPosition(blk4.position())
    cursor.setPosition(blk7.position() + blk7.length(), cursor.MoveMode.KeepAnchor)
    cursor.removeSelectedText()
    
    print(f"_folded_ranges after delete: {editor._folded_ranges}")
    # textChanged should have triggered _on_content_edited_unfold_all
    
    return

    return 0

if __name__ == "__main__":
    sys.exit(test_visual_folding())
