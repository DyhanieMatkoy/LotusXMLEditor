import sys
from PyQt6.QtWidgets import QApplication, QTextEdit
from PyQt6.QtGui import QTextCursor, QColor

# Mock XmlEditorWidget for testing highlight logic
class MockXmlEditorWidget(QTextEdit):
    def __init__(self):
        super().__init__()
        self.selectionChanged.connect(self.highlight_all_occurrences)
        
    def highlight_all_occurrences(self):
        extra_selections = []
        cursor = self.textCursor()
        if cursor.hasSelection():
            selected_text = cursor.selectedText()
            if len(selected_text) > 1:
                doc = self.document()
                search_cursor = QTextCursor(doc)
                while True:
                    search_cursor = doc.find(selected_text, search_cursor)
                    if search_cursor.isNull():
                        break
                    selection = QTextEdit.ExtraSelection()
                    selection.cursor = search_cursor
                    extra_selections.append(selection)
        self.setExtraSelections(extra_selections)

def verify_features():
    app = QApplication(sys.argv)
    editor = MockXmlEditorWidget()
    editor.setPlainText("foo bar foo baz foo")
    
    print("Test 1: Highlight Selection")
    # precise selection of first "foo"
    cursor = editor.textCursor()
    cursor.setPosition(0)
    cursor.setPosition(3, QTextCursor.MoveMode.KeepAnchor)
    editor.setTextCursor(cursor)
    
    selections = editor.extraSelections()
    print(f"Selected 'foo', found {len(selections)} highlights (Expected: 3)")
    
    if len(selections) == 3:
        print("SUCCESS: Highlight logic works.")
    else:
        print("FAILURE: Highlight logic failed.")

    print("\nTest 2: F3 Logic (Mock)")
    # Simulating the main window logic
    last_term = "old"
    if editor.textCursor().hasSelection():
        sel = editor.textCursor().selectedText()
        if len(sel) > 0:
            last_term = sel
            print(f"F3 pressed, new search term: '{last_term}' (Expected: 'foo')")
            
    if last_term == "foo":
         print("SUCCESS: F3 logic picked up selection.")
    else:
         print("FAILURE: F3 logic failed.")

if __name__ == "__main__":
    verify_features()
