import re
from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QTextEdit, 
                             QRadioButton, QButtonGroup, QPushButton, QWidget, 
                             QScrollArea, QLabel, QMenuBar, QStackedWidget, QComboBox)
from PyQt6.QtGui import QFont, QAction, QTextCursor
from PyQt6.QtCore import Qt, pyqtSignal
from highlighter import XmlHighlighter
from syntax import RuleHighlighter, LanguageProfileCompiler
from human_readable import get_human_readable_1c_xml

class FragmentEditorDialog(QDialog):
    """Dialog for editing/viewing XML fragments with selectable syntax highlighting."""
    
    save_requested = pyqtSignal(str)

    def __init__(self, text, language_registry, initial_language='XML', parent=None):
        super().__init__(parent)
        self.setWindowTitle("Fragment Editor")
        self.resize(900, 600)
        self.language_registry = language_registry
        
        # Initialize editor first so menu actions can connect to it
        self.editor = QTextEdit()
        self.editor.setFont(QFont("Consolas", 11))
        self.editor.setPlainText(text)
        self.editor.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
        
        # Context Menu
        self.editor.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.editor.customContextMenuRequested.connect(self._show_context_menu)

        layout = QVBoxLayout(self)
        
        # Menu
        self.menubar = self._setup_menu()
        layout.setMenuBar(self.menubar)
        
        # Top bar with syntax selection
        top_layout = QHBoxLayout()
        
        # View Mode Selector
        top_layout.addWidget(QLabel("Mode:"))
        self.view_mode_combo = QComboBox()
        self.view_mode_combo.addItems(["Code Editor", "1C Human Readable"])
        self.view_mode_combo.currentIndexChanged.connect(self._on_view_mode_changed)
        top_layout.addWidget(self.view_mode_combo)
        
        top_layout.addSpacing(20)
        
        self.syntax_label = QLabel("Syntax:")
        top_layout.addWidget(self.syntax_label)
        
        self.syntax_group = QButtonGroup(self)
        self.syntax_group.buttonClicked.connect(self._on_syntax_changed)
        
        # Scroll area for radio buttons if there are many languages
        self.syntax_scroll = QScrollArea()
        self.syntax_scroll.setWidgetResizable(True)
        self.syntax_scroll.setFixedHeight(50)
        self.syntax_scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        
        scroll_content = QWidget()
        scroll_layout = QHBoxLayout(scroll_content)
        scroll_layout.setContentsMargins(0, 0, 0, 0)
        scroll_layout.setSpacing(15)
        
        # XML option (always present)
        rb_xml = QRadioButton("XML")
        self.syntax_group.addButton(rb_xml)
        scroll_layout.addWidget(rb_xml)
        if initial_language == 'XML':
            rb_xml.setChecked(True)
            
        # Other languages from registry
        languages = self.language_registry.list()
        for lang_name in languages:
            rb = QRadioButton(lang_name)
            self.syntax_group.addButton(rb)
            scroll_layout.addWidget(rb)
            if lang_name == initial_language:
                rb.setChecked(True)
                
        scroll_layout.addStretch()
        self.syntax_scroll.setWidget(scroll_content)
        top_layout.addWidget(self.syntax_scroll)
        
        layout.addLayout(top_layout)
        
        # Stacked Widget for Editor and Viewer
        self.stack = QStackedWidget()
        self.stack.addWidget(self.editor)
        
        self.viewer_1c = QTextEdit()
        self.viewer_1c.setFont(QFont("Consolas", 11))
        self.viewer_1c.setReadOnly(True)
        self.stack.addWidget(self.viewer_1c)
        
        layout.addWidget(self.stack)
        
        # Bottom button bar
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        
        self.btn_save = QPushButton("Save")
        self.btn_save.clicked.connect(self._on_save)
        self.btn_save.setDefault(True)
        btn_layout.addWidget(self.btn_save)

        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.reject)
        btn_layout.addWidget(btn_close)
        
        layout.addLayout(btn_layout)
        
        # Apply initial highlighting
        self._apply_highlighting(initial_language)

    def _on_save(self):
        """Handle save button click"""
        self.save_requested.emit(self.editor.toPlainText())
        self.accept()

    def _setup_menu(self):
        menubar = QMenuBar()
        edit_menu = menubar.addMenu("Edit")
        
        undo_action = QAction("Undo", self)
        undo_action.setShortcut("Ctrl+Z")
        undo_action.triggered.connect(self.editor.undo)
        edit_menu.addAction(undo_action)
        
        redo_action = QAction("Redo", self)
        redo_action.setShortcut("Ctrl+Y")
        redo_action.triggered.connect(self.editor.redo)
        edit_menu.addAction(redo_action)
        
        edit_menu.addSeparator()
        
        cut_action = QAction("Cut", self)
        cut_action.setShortcut("Ctrl+X")
        cut_action.triggered.connect(self.editor.cut)
        edit_menu.addAction(cut_action)
        
        copy_action = QAction("Copy", self)
        copy_action.setShortcut("Ctrl+C")
        copy_action.triggered.connect(self.editor.copy)
        edit_menu.addAction(copy_action)
        
        paste_action = QAction("Paste", self)
        paste_action.setShortcut("Ctrl+V")
        paste_action.triggered.connect(self.editor.paste)
        edit_menu.addAction(paste_action)
        
        select_all_action = QAction("Select All", self)
        select_all_action.setShortcut("Ctrl+A")
        select_all_action.triggered.connect(self.editor.selectAll)
        edit_menu.addAction(select_all_action)
        
        edit_menu.addSeparator()
        
        toggle_comment_action = QAction("Toggle Comment", self)
        toggle_comment_action.setShortcut("Ctrl+/")
        toggle_comment_action.triggered.connect(self.toggle_comment)
        edit_menu.addAction(toggle_comment_action)

        remove_empty_lines_action = QAction("Remove Empty Lines", self)
        remove_empty_lines_action.triggered.connect(self.remove_empty_lines)
        edit_menu.addAction(remove_empty_lines_action)
        
        return menubar

    def remove_empty_lines(self):
        cursor = self.editor.textCursor()
        if not cursor.hasSelection():
            return
            
        selection_start = cursor.selectionStart()
        selection_end = cursor.selectionEnd()
        
        text = self.editor.toPlainText()
        selected_text = text[selection_start:selection_end]
        
        if not selected_text:
            return

        lines = selected_text.split('\n')
        # Filter out empty lines or lines with only whitespace
        non_empty_lines = [line for line in lines if line.strip()]
        
        # Join with newlines
        new_text = '\n'.join(non_empty_lines)
        
        if new_text == selected_text:
            return
            
        cursor.beginEditBlock()
        cursor.insertText(new_text)
        cursor.endEditBlock()

    def _show_context_menu(self, position):
        menu = self.editor.createStandardContextMenu()
        menu.addSeparator()
        
        toggle_action = menu.addAction("Toggle Comment")
        toggle_action.setShortcut("Ctrl+/")
        toggle_action.triggered.connect(self.toggle_comment)
        
        remove_lines_action = menu.addAction("Remove Empty Lines")
        remove_lines_action.triggered.connect(self.remove_empty_lines)
        
        menu.exec(self.editor.mapToGlobal(position))

    def toggle_comment(self):
        """Toggle comment based on current syntax language."""
        try:
            current_lang = 'XML'
            if self.syntax_group.checkedButton():
                current_lang = self.syntax_group.checkedButton().text()
            
            # Check for 1c-Ent syntax (case-insensitive check)
            is_1c = '1c' in current_lang.lower() or 'ent' in current_lang.lower()
            
            if is_1c:
                self._toggle_line_comments(prefix="//")
            else:
                self.toggle_block_comment()
        except Exception as e:
            print(f"Toggle comment error: {e}")

    def _toggle_line_comments(self, prefix: str = "//"):
        """Toggle comment prefix at beginning of selected lines or current line."""
        cursor = self.editor.textCursor()
        cursor.beginEditBlock()
        
        try:
            start_pos = cursor.selectionStart()
            end_pos = cursor.selectionEnd()
            
            # Get block range
            cursor.setPosition(start_pos)
            start_block = cursor.blockNumber()
            
            cursor.setPosition(end_pos)
            # If at start of block and not empty selection, exclude this block
            if cursor.atBlockStart() and end_pos > start_pos:
                cursor.movePosition(QTextCursor.MoveOperation.PreviousBlock)
            end_block = cursor.blockNumber()
            
            doc = self.editor.document()
            
            # Analyze lines to decide: comment or uncomment?
            all_commented = True
            has_content = False
            
            for i in range(start_block, end_block + 1):
                block = doc.findBlockByNumber(i)
                text = block.text()
                stripped = text.lstrip()
                if stripped:
                    has_content = True
                    if not stripped.startswith(prefix):
                        all_commented = False
                        break
            
            # If no content (empty lines), treat as uncommented -> comment them
            # If all content lines are commented, we uncomment.
            should_uncomment = all_commented and has_content
            
            # Apply changes
            for i in range(start_block, end_block + 1):
                block = doc.findBlockByNumber(i)
                text = block.text()
                
                # Use a new cursor for modification
                line_cursor = QTextCursor(doc)
                line_cursor.setPosition(block.position())
                
                if should_uncomment:
                    stripped = text.lstrip()
                    if stripped.startswith(prefix):
                        indent = len(text) - len(stripped)
                        # Move to prefix start
                        line_cursor.setPosition(block.position() + indent)
                        # Select prefix
                        line_cursor.movePosition(QTextCursor.MoveOperation.Right, QTextCursor.MoveMode.KeepAnchor, len(prefix))
                        line_cursor.removeSelectedText()
                else:
                    # Add comment
                    if not text.strip():
                         line_cursor.insertText(prefix)
                    else:
                        indent = len(text) - len(text.lstrip())
                        line_cursor.setPosition(block.position() + indent)
                        line_cursor.insertText(prefix)
                        
        except Exception as e:
            print(f"Toggle line comments error: {e}")
        finally:
            cursor.endEditBlock()

    def toggle_block_comment(self, start_marker="<!--", end_marker="-->"):
        """Toggle block comment around selection or current line."""
        try:
            cursor = self.editor.textCursor()
            if not cursor.hasSelection():
                 cursor.select(QTextCursor.SelectionType.LineUnderCursor)
            
            text = cursor.selectedText()
            # Normalize newlines
            normalized_text = text.replace('\\u2029', '\\n')
            
            # Check if already commented
            pattern = fr"^\\s*{re.escape(start_marker)}[\\s\\S]*{re.escape(end_marker)}\\s*$"
            if re.match(pattern, normalized_text):
                # Unwrap
                s_idx = normalized_text.find(start_marker)
                e_idx = normalized_text.rfind(end_marker)
                
                if s_idx != -1 and e_idx != -1 and e_idx > s_idx:
                     # Extract inner content
                     inner = normalized_text[s_idx+len(start_marker):e_idx]
                     if inner.startswith(' ') and inner.endswith(' ') and len(inner) >= 2:
                         inner = inner[1:-1]
                     
                     pre = normalized_text[:s_idx]
                     post = normalized_text[e_idx+len(end_marker):]
                     new_text = pre + inner + post
                     cursor.insertText(new_text)
            else:
                # Wrap
                trailing_newline = ""
                if normalized_text.endswith('\\n'):
                    normalized_text = normalized_text[:-1]
                    trailing_newline = "\\n"
                
                cursor.insertText(f"{start_marker} {normalized_text} {end_marker}{trailing_newline}")
        except Exception as e:
            print(f"Toggle block comment error: {e}")

    def _on_syntax_changed(self, button):
        lang = button.text()
        self._apply_highlighting(lang)

    def _apply_highlighting(self, lang_name):
        try:
            # Clear existing highlighter
            if hasattr(self.editor, 'highlighter') and self.editor.highlighter:
                self.editor.highlighter.setDocument(None)
                self.editor.highlighter = None

            if lang_name == 'XML':
                self.editor.highlighter = XmlHighlighter(self.editor.document())
            else:
                ld = self.language_registry.get(lang_name)
                if ld:
                    rules = LanguageProfileCompiler(ld).compile()
                    self.editor.highlighter = RuleHighlighter(self.editor.document(), rules)
                else:
                    # Fallback
                    self.editor.highlighter = XmlHighlighter(self.editor.document())
        except Exception as e:
            print(f"Fragment highlighting error: {e}")
    
    def _on_view_mode_changed(self, index):
        if index == 0: # Code Editor
            self.stack.setCurrentIndex(0)
            self.syntax_label.setVisible(True)
            self.syntax_scroll.setVisible(True)
            # Enable save button? It's always enabled.
        else: # 1C Human Readable
            # Generate view
            xml_text = self.editor.toPlainText()
            readable_text = get_human_readable_1c_xml(xml_text)
            self.viewer_1c.setPlainText(readable_text)
            
            self.stack.setCurrentIndex(1)
            self.syntax_label.setVisible(False)
            self.syntax_scroll.setVisible(False)
    
    def closeEvent(self, event):
        """Handle dialog close event safely"""
        try:
            # Clean up highlighter to prevent crashes
            if hasattr(self.editor, 'highlighter') and self.editor.highlighter:
                self.editor.highlighter.setDocument(None)
                self.editor.highlighter = None
            super().closeEvent(event)
        except Exception as e:
            print(f"Fragment editor close error: {e}")
            super().closeEvent(event)
