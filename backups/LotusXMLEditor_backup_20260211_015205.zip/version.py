"""
Version information for Lotus XML Editor
This file is automatically updated during build process
"""

__version__ = "2026-02-04"
__build_date__ = "2026-02-05"
__app_name__ = "Lotus26 XML Editor"
