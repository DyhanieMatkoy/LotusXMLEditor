"""
Line Number Widget for QTextEdit
Displays line numbers in a sidebar next to the text editor with fold/unfold controls
"""

from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import Qt, QRect, QSize
from PyQt6.QtGui import QPainter, QColor, QTextBlock, QPen, QBrush, QPolygon
from PyQt6.QtCore import QPoint


class LineNumberWidget(QWidget):
    """Widget that displays line numbers for a QTextEdit with fold controls"""
    
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor
        self.setStyleSheet("background-color: #2b2b2b;")
        self.setMouseTracking(True)
        self.hover_line = -1
        self.folding_enabled = True
        
    def set_folding_enabled(self, enabled):
        """Enable or disable code folding features"""
        self.folding_enabled = enabled
        self.update()
    
    def sizeHint(self):
        """Calculate the width needed for line numbers"""
        return QSize(self.calculate_width(), 0)
    
    def calculate_width(self):
        """Calculate width based on number of lines"""
        digits = len(str(max(1, self.editor.document().blockCount())))
        # Width = 8px padding + (8px per digit) + 16px for fold controls + 8px padding
        # If folding is disabled, remove the 16px for fold controls
        fold_width = 16 if self.folding_enabled else 0
        return 24 + self.fontMetrics().horizontalAdvance('9') * digits + fold_width
    
    def mouseMoveEvent(self, event):
        """Track mouse hover for fold control highlighting"""
        y = event.pos().y()
        viewport_offset = self.editor.verticalScrollBar().value()
        
        block = self.editor.document().firstBlock()
        block_number = 0
        hover_line = -1
        
        while block.isValid():
            if not block.isVisible():
                block = block.next()
                block_number += 1
                continue

            block_geometry = self.editor.document().documentLayout().blockBoundingRect(block)
            
            if block_geometry.top() - viewport_offset > y:
                break
                
            if block_geometry.bottom() - viewport_offset >= y:
                hover_line = block_number + 1
                break
            
            block = block.next()
            block_number += 1
        
        if hover_line != self.hover_line:
            self.hover_line = hover_line
            self.update()
    
    def leaveEvent(self, event):
        """Clear hover state when mouse leaves"""
        self.hover_line = -1
        self.update()
    
    def mousePressEvent(self, event):
        """Handle click on fold controls"""
        if event.button() != Qt.MouseButton.LeftButton:
            return
            
        y = event.pos().y()
        x = event.pos().x()
        viewport_offset = self.editor.verticalScrollBar().value()
        
        # Check if click is in the fold control area (left 16px)
        if x > 16:
            return
            
        # If folding is disabled, ignore clicks in the fold area
        if not self.folding_enabled:
            return
        
        block = self.editor.document().firstBlock()
        block_number = 0
        
        while block.isValid():
            if not block.isVisible():
                block = block.next()
                block_number += 1
                continue
            
            block_geometry = self.editor.document().documentLayout().blockBoundingRect(block)
            
            if block_geometry.top() - viewport_offset > y:
                break
                
            if block_geometry.bottom() - viewport_offset >= y:
                line_number = block_number + 1
                self._toggle_fold_at_line(line_number)
                break
            
            block = block.next()
            block_number += 1
    
    def _toggle_fold_at_line(self, line_number):
        """Toggle fold at the specified line"""
        try:
            # Check if this line is already folded
            folded_ranges = getattr(self.editor, '_folded_ranges', [])
            
            # Check if clicking on a folded range start
            for start, end in folded_ranges:
                if start == line_number:
                    # Unfold this range
                    self.editor.unfold_lines(start, end)
                    return
            
            # Otherwise, try to fold at this line
            # Get the main window to compute the range
            main_window = self.editor.window()
            if hasattr(main_window, '_compute_range_lines_at_cursor'):
                # Temporarily move cursor to this line
                # Block signals to prevent sync/scroll during calculation
                was_blocked = self.editor.blockSignals(True)
                try:
                    cursor = self.editor.textCursor()
                    old_pos = cursor.position()
                    
                    # Move to the line
                    cursor.movePosition(cursor.MoveOperation.Start)
                    for _ in range(line_number - 1):
                        cursor.movePosition(cursor.MoveOperation.Down)
                    
                    self.editor.setTextCursor(cursor)
                    
                    # Compute range and fold
                    rng = main_window._compute_range_lines_at_cursor()
                    if rng:
                        self.editor.fold_lines(rng[0], rng[1])
                    
                    # Restore cursor position
                    cursor.setPosition(old_pos)
                    self.editor.setTextCursor(cursor)
                finally:
                    self.editor.blockSignals(was_blocked)
        except Exception as e:
            print(f"Toggle fold error: {e}")
    
    def paintEvent(self, event):
        """Paint line numbers with fold controls"""
        painter = QPainter(self)
        painter.fillRect(event.rect(), QColor(43, 43, 43))
        
        # Get the first visible block
        block = self.editor.document().firstBlock()
        block_number = 0
        
        # Find first visible block
        viewport_offset = self.editor.verticalScrollBar().value()
        
        # Set text color
        painter.setPen(QColor(150, 150, 150))
        
        # Get folded ranges
        folded_ranges = getattr(self.editor, '_folded_ranges', [])
        folded_starts = {start for start, end in folded_ranges}
        
        # Draw line numbers and fold controls for all blocks
        while block.isValid():
            if not block.isVisible():
                block = block.next()
                block_number += 1
                continue
                
            # Get block geometry
            block_geometry = self.editor.document().documentLayout().blockBoundingRect(block)
            
            # Check if block is visible in viewport
            if block_geometry.top() - viewport_offset > event.rect().bottom():
                break
                
            if block_geometry.bottom() - viewport_offset >= event.rect().top():
                line_number = block_number + 1
                number = str(line_number)
                
                # Draw fold control if this line can be folded or is folded
                fold_x = 4
                fold_y = int(block_geometry.top() - viewport_offset + block_geometry.height() / 2)
                
                # Check if this line is a fold start
                is_folded = line_number in folded_starts
                
                # Draw fold indicator (triangle or box)
                if self.folding_enabled and (is_folded or line_number == self.hover_line):
                    painter.save()
                    
                    if is_folded:
                        # Draw right-pointing triangle (folded)
                        painter.setBrush(QBrush(QColor(150, 150, 150)))
                        painter.setPen(QPen(QColor(150, 150, 150)))
                        triangle = QPolygon([
                            QPoint(fold_x, fold_y - 4),
                            QPoint(fold_x, fold_y + 4),
                            QPoint(fold_x + 6, fold_y)
                        ])
                        painter.drawPolygon(triangle)
                    elif line_number == self.hover_line:
                        # Draw down-pointing triangle (can be folded)
                        painter.setBrush(QBrush(QColor(100, 100, 100)))
                        painter.setPen(QPen(QColor(100, 100, 100)))
                        triangle = QPolygon([
                            QPoint(fold_x, fold_y - 2),
                            QPoint(fold_x + 8, fold_y - 2),
                            QPoint(fold_x + 4, fold_y + 4)
                        ])
                        painter.drawPolygon(triangle)
                    
                    painter.restore()
                
                # Draw line number
                painter.drawText(16, int(block_geometry.top() - viewport_offset), 
                               self.width() - 20, 
                               int(block_geometry.height()),
                               Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, 
                               number)
            
            block = block.next()
            block_number += 1
