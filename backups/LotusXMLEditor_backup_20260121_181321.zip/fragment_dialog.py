from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QTextEdit, 
                             QRadioButton, QButtonGroup, QPushButton, QWidget, QScrollArea, QLabel)
from PyQt6.QtGui import QFont, QAction
from PyQt6.QtCore import Qt
from highlighter import XmlHighlighter
from syntax import RuleHighlighter, LanguageProfileCompiler

class FragmentEditorDialog(QDialog):
    """Dialog for editing/viewing XML fragments with selectable syntax highlighting."""
    
    def __init__(self, text, language_registry, initial_language='XML', parent=None):
        super().__init__(parent)
        self.setWindowTitle("Fragment Editor")
        self.resize(900, 600)
        self.language_registry = language_registry
        
        layout = QVBoxLayout(self)
        
        # Top bar with syntax selection
        top_layout = QHBoxLayout()
        top_layout.addWidget(QLabel("Syntax:"))
        
        self.syntax_group = QButtonGroup(self)
        self.syntax_group.buttonClicked.connect(self._on_syntax_changed)
        
        # Scroll area for radio buttons if there are many languages
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(50)
        scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        
        scroll_content = QWidget()
        scroll_layout = QHBoxLayout(scroll_content)
        scroll_layout.setContentsMargins(0, 0, 0, 0)
        scroll_layout.setSpacing(15)
        
        # XML option (always present)
        rb_xml = QRadioButton("XML")
        self.syntax_group.addButton(rb_xml)
        scroll_layout.addWidget(rb_xml)
        if initial_language == 'XML':
            rb_xml.setChecked(True)
            
        # Other languages from registry
        languages = self.language_registry.list()
        for lang_name in languages:
            rb = QRadioButton(lang_name)
            self.syntax_group.addButton(rb)
            scroll_layout.addWidget(rb)
            if lang_name == initial_language:
                rb.setChecked(True)
                
        scroll_layout.addStretch()
        scroll.setWidget(scroll_content)
        top_layout.addWidget(scroll)
        
        layout.addLayout(top_layout)
        
        # Editor
        self.editor = QTextEdit()
        self.editor.setFont(QFont("Consolas", 11))
        self.editor.setPlainText(text)
        self.editor.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
        layout.addWidget(self.editor)
        
        # Bottom button bar
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        
        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.accept)
        btn_layout.addWidget(btn_close)
        
        layout.addLayout(btn_layout)
        
        # Apply initial highlighting
        self._apply_highlighting(initial_language)

    def _on_syntax_changed(self, button):
        lang = button.text()
        self._apply_highlighting(lang)

    def _apply_highlighting(self, lang_name):
        try:
            # Clear existing highlighter
            if hasattr(self.editor, 'highlighter') and self.editor.highlighter:
                self.editor.highlighter.setDocument(None)
                self.editor.highlighter = None

            if lang_name == 'XML':
                self.editor.highlighter = XmlHighlighter(self.editor.document())
            else:
                ld = self.language_registry.get(lang_name)
                if ld:
                    rules = LanguageProfileCompiler(ld).compile()
                    self.editor.highlighter = RuleHighlighter(self.editor.document(), rules)
                else:
                    # Fallback
                    self.editor.highlighter = XmlHighlighter(self.editor.document())
        except Exception as e:
            print(f"Fragment highlighting error: {e}")
    
    def closeEvent(self, event):
        """Handle dialog close event safely"""
        try:
            # Clean up highlighter to prevent crashes
            if hasattr(self.editor, 'highlighter') and self.editor.highlighter:
                self.editor.highlighter.setDocument(None)
                self.editor.highlighter = None
            super().closeEvent(event)
        except Exception as e:
            print(f"Fragment editor close error: {e}")
            super().closeEvent(event)
