# Implementation Plan: XML Metro Navigator

## Overview

Реализация интерактивного графического навигатора по XML-структуре в виде карты метро. Система будет интегрирована в существующее приложение Lotus XML Editor и использует PyQt6 для графического интерфейса. Реализация включает алгоритм интеллектуального размещения узлов, интерактивное взаимодействие и интеграцию с основным редактором.

## Tasks

- [ ] 1. Создать базовую структуру модуля metro_navigator
  - Создать файл `metro_navigator.py` с основными классами
  - Определить структуру данных `MetroGraphNode` в `models.py`
  - Определить структуру `MetroNavigatorSettings` для сохранения состояния
  - _Requirements: 1.1, 7.1_

- [ ] 1.1 Написать property-тест для MetroGraphNode
  - **Property 1: Three-level depth limit**
  - **Validates: Requirements 1.1, 1.2**

- [ ] 2. Реализовать парсинг и извлечение 3 уровней XML
  - [ ] 2.1 Создать функцию `extract_three_levels()` в XmlService
    - Функция принимает XML-контент и возвращает дерево до 3 уровня
    - Использовать существующий `parse_xml()` и `build_xml_tree()`
    - Ограничить рекурсию до уровня 2 (0, 1, 2 = 3 уровня)
    - _Requirements: 1.1, 1.2_

  - [ ] 2.2 Написать property-тест для извлечения 3 уровней
    - **Property 1: Three-level depth limit**
    - **Validates: Requirements 1.1, 1.2**

  - [ ] 2.3 Добавить обработку ошибок парсинга
    - Возвращать описательное сообщение при невалидном XML
    - _Requirements: 1.3_

  - [ ] 2.4 Написать property-тест для обработки ошибок
    - **Property: Error handling for invalid XML**
    - **Validates: Requirements 1.3**

  - [ ] 2.5 Сохранять атрибуты узлов в MetroGraphNode
    - Убедиться, что атрибуты копируются из XmlTreeNode
    - _Requirements: 1.4_

  - [ ] 2.6 Написать property-тест для сохранения атрибутов
    - **Property: Attribute preservation**
    - **Validates: Requirements 1.4**

- [ ] 3. Checkpoint - Проверить парсинг и структуру данных
  - Убедиться, что все тесты парсинга проходят
  - Спросить пользователя, если возникли вопросы

- [ ] 4. Реализовать алгоритм размещения узлов (MetroLayoutEngine)
  - [ ] 4.1 Создать класс `MetroLayoutEngine`
    - Метод `compute_layout()` для вычисления позиций
    - Начальное размещение: корень сверху, дети распределены по уровням
    - _Requirements: 2.1, 2.2_

  - [ ] 4.2 Реализовать force-directed layout
    - Репульсивные силы между всеми узлами
    - Притягивающие силы вдоль рёбер (родитель-ребёнок)
    - Итеративная симуляция (100-200 итераций)
    - _Requirements: 2.1, 2.2_

  - [ ] 4.3 Добавить проверку минимального расстояния между узлами
    - Метод `_detect_collisions()` для обнаружения близких узлов
    - Метод `_resolve_collisions()` для разрешения коллизий
    - Минимальное расстояние: 80 пикселей
    - _Requirements: 2.4_

  - [ ] 4.4 Написать property-тест для минимального расстояния
    - **Property 2: Minimum node spacing**
    - **Validates: Requirements 2.4**

  - [ ] 4.5 Добавить вертикальное выравнивание по уровням
    - Узлы одного уровня должны быть на одной высоте (±10px)
    - Минимальное расстояние между уровнями: 120 пикселей
    - _Requirements: 2.5_

  - [ ] 4.6 Написать property-тест для вертикального расстояния
    - **Property 3: Vertical level spacing**
    - **Validates: Requirements 2.5**

  - [ ] 4.7 Реализовать пропорциональное распределение пространства
    - Узлы с большим количеством детей получают больше горизонтального пространства
    - _Requirements: 2.2_

  - [ ] 4.8 Написать property-тест для пропорционального распределения
    - **Property: Proportional space allocation**
    - **Validates: Requirements 2.2**

  - [ ] 4.9 Добавить группировку узлов по родителям (для >50 узлов)
    - Дочерние узлы должны быть ближе к родителю, чем к другим узлам
    - _Requirements: 2.3_

  - [ ] 4.10 Написать property-тест для группировки
    - **Property: Parent-child proximity**
    - **Validates: Requirements 2.3**

  - [ ] 4.11 Написать property-тест для детерминизма layout
    - **Property 7: Layout determinism**
    - **Validates: Requirements 2.1, 2.2**

  - [ ] 4.12 Написать property-тест для отсутствия коллизий
    - **Property 8: Collision-free layout**
    - **Validates: Requirements 2.1, 2.4**

- [ ] 5. Checkpoint - Проверить алгоритм размещения
  - Убедиться, что все тесты layout проходят
  - Визуально проверить размещение на тестовых данных
  - Спросить пользователя, если возникли вопросы

- [ ] 6. Реализовать графические элементы (StationNode, ConnectionLine)
  - [ ] 6.1 Создать класс `StationNode` (наследник QGraphicsItem)
    - Метод `paint()` для отрисовки станции в стиле метро
    - Метод `boundingRect()` для определения границ
    - Отображение имени узла
    - Размер зависит от уровня (корень больше)
    - _Requirements: 3.1, 3.2_

  - [ ] 6.2 Добавить индикатор количества детей
    - Показывать бейдж с числом дочерних элементов
    - _Requirements: 3.3_

  - [ ] 6.3 Написать property-тест для индикатора детей
    - **Property: Child count indicator**
    - **Validates: Requirements 3.3**

  - [ ] 6.4 Реализовать адаптивное отображение в зависимости от zoom
    - При zoom < 0.5: только имя узла
    - При zoom > 1.5: имя + атрибуты + количество детей
    - Метод `set_zoom_level()` для обновления отображения
    - _Requirements: 5.2, 5.3_

  - [ ] 6.5 Написать property-тест для адаптивного отображения
    - **Property 12: Adaptive detail display**
    - **Validates: Requirements 5.2, 5.3**

  - [ ] 6.6 Добавить обработку кликов на узлах
    - Одинарный клик: выделить узел, испустить сигнал `node_selected`
    - Двойной клик: испустить сигнал `open_in_editor_requested`
    - _Requirements: 4.1, 4.2_

  - [ ] 6.7 Написать property-тест для кликов
    - **Property 5: Node selection synchronization**
    - **Validates: Requirements 4.1, 7.3**

  - [ ] 6.8 Создать класс `ConnectionLine` (наследник QGraphicsLineItem)
    - Отрисовка линии между родителем и ребёнком
    - Стиль: закруглённые углы, цвет линии метро
    - Метод `update_position()` для обновления при перемещении узлов
    - _Requirements: 3.5_

  - [ ] 6.9 Добавить подсветку пути от корня до выбранного узла
    - Метод `set_highlighted()` для узлов и линий
    - _Requirements: 4.5_

  - [ ] 6.10 Написать property-тест для подсветки пути
    - **Property 6: Path highlighting correctness**
    - **Validates: Requirements 4.5**

- [ ] 7. Реализовать MetroCanvasScene и MetroCanvasView
  - [ ] 7.1 Создать класс `MetroCanvasScene` (наследник QGraphicsScene)
    - Метод `build_graph()` для построения графа из XmlTreeNode
    - Создание StationNode для каждого узла
    - Создание ConnectionLine для каждого ребра
    - Использование MetroLayoutEngine для позиционирования
    - _Requirements: 1.1, 2.1_

  - [ ] 7.2 Добавить методы выбора и подсветки
    - Метод `select_node(xpath)` для выбора узла по XPath
    - Метод `highlight_path(xpath)` для подсветки пути
    - Сигнал `node_selected` при клике на узел
    - _Requirements: 4.1, 4.5_

  - [ ] 7.3 Создать класс `MetroCanvasView` (наследник QGraphicsView)
    - Настройка viewport для плавной отрисовки
    - Включить antialiasing для качественной графики
    - _Requirements: 3.1_

  - [ ] 7.4 Реализовать масштабирование колесом мыши
    - Обработка `wheelEvent()` с Ctrl для zoom
    - Ограничение zoom в диапазоне [0.25, 4.0]
    - Zoom с центром в позиции курсора
    - _Requirements: 4.4, 5.1_

  - [ ] 7.5 Написать property-тест для диапазона zoom
    - **Property 4: Zoom range bounds**
    - **Validates: Requirements 5.1**

  - [ ] 7.6 Реализовать перетаскивание холста
    - Включить `ScrollHandDrag` режим
    - _Requirements: 4.3_

  - [ ] 7.7 Добавить метод `fit_to_view()`
    - Автоматический подбор масштаба для отображения всего графа
    - _Requirements: 5.4_

  - [ ] 7.8 Реализовать виртуализацию для больших графов (>100 узлов)
    - Отрисовка только узлов в видимой области viewport
    - Использовать `itemsBoundingRect()` для определения видимости
    - _Requirements: 6.1_

  - [ ] 7.9 Написать property-тест для виртуализации
    - **Property 10: Viewport virtualization threshold**
    - **Validates: Requirements 6.1**

- [ ] 8. Checkpoint - Проверить графические элементы
  - Убедиться, что узлы и линии отрисовываются корректно
  - Проверить zoom и pan
  - Спросить пользователя, если возникли вопросы

- [ ] 9. Реализовать NodeInfoPanel
  - [ ] 9.1 Создать класс `NodeInfoPanel` (наследник QWidget)
    - Отображение имени узла, атрибутов, количества детей
    - Кнопка "Open in Editor" для открытия в редакторе
    - Сигнал `open_in_editor_requested(xpath)`
    - _Requirements: 4.1_

  - [ ] 9.2 Добавить метод `show_node_info(xml_node)`
    - Обновление панели при выборе узла
    - _Requirements: 4.1_

- [ ] 10. Реализовать главное окно MetroNavigatorWindow
  - [ ] 10.1 Создать класс `MetroNavigatorWindow` (наследник QMainWindow)
    - Компоновка: MetroCanvasView (центр) + NodeInfoPanel (справа)
    - Toolbar с кнопками: Fit to View, Zoom In, Zoom Out
    - Индикатор текущего zoom в статус-баре
    - _Requirements: 7.1_

  - [ ] 10.2 Добавить метод `load_xml(xml_content)`
    - Парсинг XML через XmlService
    - Извлечение 3 уровней
    - Построение графа через MetroCanvasScene
    - Показ индикатора загрузки для больших файлов
    - _Requirements: 1.1, 6.4_

  - [ ] 10.3 Реализовать синхронизацию с редактором
    - Метод `sync_with_editor(xpath)` для выделения узла из редактора
    - Подключение сигнала `node_selected` к callback главного окна
    - _Requirements: 7.3_

  - [ ] 10.4 Написать property-тест для синхронизации
    - **Property 5: Node selection synchronization**
    - **Validates: Requirements 4.1, 7.3**

  - [ ] 10.5 Добавить сохранение и восстановление настроек
    - Метод `get_current_settings()` для получения zoom и позиции
    - Метод `restore_settings(settings)` для восстановления
    - Использовать QSettings для persistence
    - _Requirements: 7.5_

  - [ ] 10.6 Написать property-тест для persistence настроек
    - **Property 9: Settings persistence round-trip**
    - **Validates: Requirements 7.5**

- [ ] 11. Интегрировать с главным приложением (main.py)
  - [ ] 11.1 Добавить пункт меню "View → XML Metro Navigator"
    - Shortcut: Ctrl+M
    - Действие: открыть MetroNavigatorWindow с текущим XML
    - _Requirements: 7.1_

  - [ ] 11.2 Добавить проверку наличия открытого XML
    - Если XML не открыт, показать сообщение
    - Предложить выбрать файл для открытия
    - _Requirements: 7.2_

  - [ ] 11.3 Подключить синхронизацию выбора узла
    - При выборе узла в навигаторе, переместить курсор в редакторе
    - Использовать XPath для поиска позиции в тексте
    - _Requirements: 7.3_

  - [ ] 11.4 Добавить предложение обновления при изменении XML
    - Отслеживать изменения в редакторе
    - Показывать кнопку "Refresh Navigator" в навигаторе
    - _Requirements: 7.4_

- [ ] 12. Checkpoint - Проверить интеграцию
  - Убедиться, что навигатор открывается из меню
  - Проверить синхронизацию с редактором
  - Спросить пользователя, если возникли вопросы

- [ ] 13. Написать интеграционные тесты
  - [ ] 13.1 Тест открытия навигатора из меню
    - Проверить, что окно создаётся с правильным XML
    - _Requirements: 7.1_

  - [ ] 13.2 Тест синхронизации выбора
    - Проверить, что выбор в навигаторе обновляет редактор
    - _Requirements: 7.3_

  - [ ] 13.3 Тест обработки пустого XML
    - Проверить, что показывается сообщение "No structure to visualize"
    - _Requirements: 7.2_

- [ ] 14. Написать performance тесты
  - [ ] 14.1 Тест времени расчёта layout для 200 узлов
    - Проверить, что расчёт занимает < 2 секунд
    - _Requirements: 6.3_

  - [ ] 14.2 Тест FPS при pan/zoom
    - Измерить frame rate во время взаимодействия
    - Цель: >= 30 FPS
    - _Requirements: 6.2_

- [ ] 15. Финальная проверка и полировка
  - Убедиться, что все обязательные тесты проходят
  - Проверить работу на реальных XML-файлах из проекта
  - Добавить комментарии и docstrings
  - Обновить документацию в doc/

## Notes

- Все задачи являются обязательными для комплексной реализации
- Каждая задача ссылается на конкретные требования для отслеживаемости
- Checkpoints обеспечивают инкрементальную валидацию
- Property-тесты проверяют универсальные свойства корректности
- Unit-тесты проверяют конкретные примеры и граничные случаи
- Интеграционные и performance тесты включены для production-ready кода
