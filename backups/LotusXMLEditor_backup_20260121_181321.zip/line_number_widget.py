"""
Line Number Widget for QTextEdit
Displays line numbers in a sidebar next to the text editor
"""

from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import Qt, QRect, QSize
from PyQt6.QtGui import QPainter, QColor, QTextBlock


class LineNumberWidget(QWidget):
    """Widget that displays line numbers for a QTextEdit"""
    
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor
        self.setStyleSheet("background-color: #2b2b2b;")
        
    def sizeHint(self):
        """Calculate the width needed for line numbers"""
        return QSize(self.calculate_width(), 0)
    
    def calculate_width(self):
        """Calculate width based on number of lines"""
        digits = len(str(max(1, self.editor.document().blockCount())))
        # Width = 8px padding + (8px per digit) + 8px padding
        return 16 + self.fontMetrics().horizontalAdvance('9') * digits
    
    def paintEvent(self, event):
        """Paint line numbers"""
        painter = QPainter(self)
        painter.fillRect(event.rect(), QColor(43, 43, 43))
        
        # Get the first visible block
        block = self.editor.document().firstBlock()
        block_number = 0
        
        # Find first visible block
        viewport_offset = self.editor.verticalScrollBar().value()
        
        # Set text color
        painter.setPen(QColor(150, 150, 150))
        
        # Draw line numbers for all blocks
        while block.isValid():
            # Get block geometry
            block_geometry = self.editor.document().documentLayout().blockBoundingRect(block)
            
            # Check if block is visible in viewport
            if block_geometry.top() - viewport_offset > event.rect().bottom():
                break
                
            if block_geometry.bottom() - viewport_offset >= event.rect().top():
                number = str(block_number + 1)
                painter.drawText(0, int(block_geometry.top() - viewport_offset), 
                               self.width() - 4, 
                               int(block_geometry.height()),
                               Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, 
                               number)
            
            block = block.next()
            block_number += 1
