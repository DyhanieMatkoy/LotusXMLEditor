"""
Version information for Lotus XML Editor
This file is automatically updated during build process
"""

__version__ = "2025-11-26"
__build_date__ = "2025-11-26"
__app_name__ = "Lotus XML Editor"
