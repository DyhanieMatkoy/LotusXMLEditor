"""
XML Service - Core XML processing functionality
"""

import xml.etree.ElementTree as ET
import xml.dom.minidom
from typing import List, Optional, Dict, Any
import re
import os
import pickle
import hashlib
import tempfile
from models import XmlTreeNode, XmlValidationResult, XmlValidationError, XmlStatistics
from xml_splitter import XmlSplitter, XmlSplitConfig, XmlSplitRule
from xml_part_manager import XmlPartManager

# Quick Win #4: Try to use lxml for 5-10x faster parsing (with fallback to ElementTree)
try:
    from lxml import etree as lxml_etree
    LXML_AVAILABLE = True
except ImportError:
    LXML_AVAILABLE = False


class XmlService:
    """Service for XML processing operations"""
    
    def __init__(self):
        self.namespaces = {}
        # Setup cache directory in temp folder
        self.cache_dir = os.path.join(tempfile.gettempdir(), 'lotus_xml_editor_cache')
        if not os.path.exists(self.cache_dir):
            try:
                os.makedirs(self.cache_dir)
            except Exception:
                pass

    def _get_cache_path(self, file_path: str) -> str:
        """Generate cache file path based on file path hash"""
        if not file_path:
            return None
        # Create a hash of the file path
        path_hash = hashlib.md5(file_path.encode('utf-8')).hexdigest()
        return os.path.join(self.cache_dir, f"{path_hash}.pkl")

    def load_tree_cache(self, file_path: str) -> Optional[XmlTreeNode]:
        """Load tree structure from cache if valid"""
        try:
            if not file_path or not os.path.exists(file_path):
                return None
                
            cache_path = self._get_cache_path(file_path)
            if not cache_path or not os.path.exists(cache_path):
                return None
                
            # Check if cache is stale
            file_mtime = os.path.getmtime(file_path)
            cache_mtime = os.path.getmtime(cache_path)
            
            if file_mtime > cache_mtime:
                return None
                
            with open(cache_path, 'rb') as f:
                return pickle.load(f)
        except Exception as e:
            print(f"Error loading cache: {e}")
            return None

    def save_tree_cache(self, file_path: str, root_node: XmlTreeNode):
        """Save tree structure to cache"""
        try:
            if not file_path:
                return
                
            cache_path = self._get_cache_path(file_path)
            if not cache_path:
                return
                
            with open(cache_path, 'wb') as f:
                pickle.dump(root_node, f)
        except Exception as e:
            print(f"Error saving cache: {e}")

    def parse_xml(self, xml_content: str) -> Optional[ET.Element]:
        """Parse XML content and return root element"""
        try:
            # Remove BOM if present
            if xml_content.startswith('\ufeff'):
                xml_content = xml_content[1:]
            
            # Quick Win #4: Use lxml if available (5-10x faster than ElementTree)
            if LXML_AVAILABLE:
                try:
                    # lxml is much faster for large files
                    # Try to encode properly, handling different encodings
                    try:
                        xml_bytes = xml_content.encode('utf-8')
                    except UnicodeEncodeError:
                        # If UTF-8 encoding fails, the string might already be in a different encoding
                        xml_bytes = xml_content.encode('latin-1')
                    
                    root = lxml_etree.fromstring(xml_bytes)
                    # Convert lxml element to ElementTree for compatibility
                    return ET.fromstring(lxml_etree.tostring(root))
                except Exception as lxml_error:
                    print(f"lxml parsing failed, falling back to ElementTree: {lxml_error}")
                    # Fall through to ElementTree parsing
            
            # Use incremental parsing for large files
            if len(xml_content) > 1024 * 1024:  # 1MB threshold
                parser = ET.XMLParser(target=ET.TreeBuilder())
                # Try to parse as string first, then try encoding
                try:
                    parser.feed(xml_content)
                except TypeError:
                    # If string doesn't work, try encoding
                    try:
                        parser.feed(xml_content.encode('utf-8'))
                    except UnicodeEncodeError:
                        parser.feed(xml_content.encode('latin-1'))
                root = parser.close()
            else:
                # Parse XML normally for smaller files
                try:
                    root = ET.fromstring(xml_content)
                except TypeError:
                    # Try encoding if string parsing fails
                    try:
                        root = ET.fromstring(xml_content.encode('utf-8'))
                    except UnicodeEncodeError:
                        root = ET.fromstring(xml_content.encode('latin-1'))
            
            return root
        except ET.ParseError as e:
            print(f"XML parsing error: {e}")
            return None
        except Exception as e:
            print(f"Unexpected error parsing XML: {e}")
            return None
    
    def format_xml(self, xml_content: str) -> str:
        """Format XML content with proper indentation"""
        try:
            # For large files, use a more memory-efficient approach
            if len(xml_content) > 1024 * 1024:  # 1MB threshold
                return self._format_large_xml(xml_content)
            
            # Parse and reformat normally for smaller files
            dom = xml.dom.minidom.parseString(xml_content)
            formatted = dom.toprettyxml(indent="  ")
            
            # Remove empty lines and extra whitespace
            lines = formatted.split('\n')
            cleaned_lines = []
            
            for line in lines:
                # Remove lines that are just whitespace
                if line.strip():
                    cleaned_lines.append(line.rstrip())
            
            return '\n'.join(cleaned_lines)
            
        except Exception as e:
            print(f"Error formatting XML: {e}")
            return xml_content
    
    def _format_large_xml(self, xml_content: str) -> str:
        """Format large XML files more efficiently"""
        try:
            # Use iterative parsing for large files
            parser = ET.XMLParser(target=ET.TreeBuilder(), encoding='utf-8')
            parser.feed(xml_content.encode('utf-8'))
            root = parser.close()
            
            # Build formatted XML manually to avoid memory issues
            return self._build_formatted_xml(root)
        except Exception as e:
            print(f"Error formatting large XML: {e}")
            return xml_content
    
    def _build_formatted_xml(self, element: ET.Element, level: int = 0) -> str:
        """Build formatted XML string manually"""
        indent = "  " * level
        result = []
        
        # Opening tag
        if element.attrib:
            attrs = ' '.join([f'{k}="{v}"' for k, v in element.attrib.items()])
            result.append(f"{indent}<{element.tag} {attrs}>")
        else:
            result.append(f"{indent}<{element.tag}>")
        
        # Text content
        if element.text and element.text.strip():
            result.append(element.text.strip())
        
        # Child elements
        for child in element:
            result.append(self._build_formatted_xml(child, level + 1))
        
        # Closing tag
        result.append(f"{indent}</{element.tag}>")
        
        # Tail text
        if element.tail and element.tail.strip():
            result.append(element.tail.strip())
        
        return '\n'.join(result)
    
    def validate_xml(self, xml_content: str) -> XmlValidationResult:
        """Validate XML content"""
        errors = []
        
        try:
            # Basic XML validation
            root = self.parse_xml(xml_content)
            if root is None:
                errors.append("Invalid XML structure")
                return XmlValidationResult(False, errors)
            
            # Check for common issues
            self._validate_xml_structure(xml_content, errors)
            
            # Check for unmatched tags
            self._check_unmatched_tags(xml_content, errors)
            
            # Check for proper XML declaration
            self._check_xml_declaration(xml_content, errors)
            
            return XmlValidationResult(len(errors) == 0, errors)
            
        except Exception as e:
            errors.append(f"Validation error: {str(e)}")
            return XmlValidationResult(False, errors)
    
    def _validate_xml_structure(self, xml_content: str, errors: List[str]):
        """Validate XML structure"""
        try:
            # Try to parse with ElementTree for basic validation
            ET.fromstring(xml_content)
        except ET.ParseError as e:
            error_msg = str(e)
            
            # Extract line and column information if available
            line_match = re.search(r'line (\d+)', error_msg)
            col_match = re.search(r'column (\d+)', error_msg)
            
            if line_match and col_match:
                line = line_match.group(1)
                col = col_match.group(1)
                errors.append(f"Line {line}, Column {col}: {error_msg}")
            else:
                errors.append(f"XML Structure Error: {error_msg}")
    
    def _check_unmatched_tags(self, xml_content: str, errors: List[str]):
        """Check for unmatched tags"""
        # Simple regex-based check for unmatched tags
        # This is a basic implementation - a full XML parser would be better
        
        lines = xml_content.split('\n')
        tag_stack = []
        
        for line_num, line in enumerate(lines, 1):
            # Find opening tags
            opening_tags = re.findall(r'<([a-zA-Z_][a-zA-Z0-9_-]*)', line)
            # Find closing tags
            closing_tags = re.findall(r'</([a-zA-Z_][a-zA-Z0-9_-]*)>', line)
            
            for tag in opening_tags:
                # Skip self-closing tags
                if not re.search(f'<{tag}[^>]*/>', line):
                    tag_stack.append((tag, line_num))
            
            for tag in closing_tags:
                if tag_stack and tag_stack[-1][0] == tag:
                    tag_stack.pop()
                else:
                    errors.append(f"Line {line_num}: Unmatched closing tag '</{tag}>'")
        
        # Check for unclosed tags
        for tag, line_num in tag_stack:
            errors.append(f"Line {line_num}: Unclosed tag '<{tag}>'")
    
    def _check_xml_declaration(self, xml_content: str, errors: List[str]):
        """Check XML declaration"""
        stripped = xml_content.strip()
        if not stripped.startswith('<?xml'):
            errors.append("Missing XML declaration")
        else:
            # Check for proper XML declaration format
            declaration_match = re.match(r'<\?xml\s+version="1\.0"', stripped)
            if not declaration_match:
                errors.append("Invalid XML declaration format")
    
    def build_xml_tree(self, xml_content: str, file_path: Optional[str] = None) -> Optional[XmlTreeNode]:
        """Build tree structure from XML content"""
        try:
            # Quick Win: Use lxml directly if available for O(1) line numbers and faster parsing
            if LXML_AVAILABLE:
                try:
                    # Priority: Parse directly from file if available (handles encoding automatically)
                    if file_path:
                        try:
                            parser = lxml_etree.XMLParser(recover=True)
                            tree = lxml_etree.parse(file_path, parser=parser)
                            root = tree.getroot()
                            if root is not None:
                                return self._lxml_element_to_tree_node(root)
                        except Exception as file_parse_error:
                            print(f"lxml file parse failed, falling back to content: {file_parse_error}")

                    # Fallback/Default: Parse from string content
                    # Strip BOM if present
                    if xml_content.startswith('\ufeff'):
                        xml_content = xml_content[1:]
                        
                    try:
                        xml_bytes = xml_content.encode('utf-8')
                    except UnicodeEncodeError:
                        xml_bytes = xml_content.encode('latin-1')
                    
                    parser = lxml_etree.XMLParser(recover=True)
                    root = lxml_etree.fromstring(xml_bytes, parser=parser)
                    
                    if root is None:
                        return None
                        
                    return self._lxml_element_to_tree_node(root)
                except Exception as lxml_error:
                    print(f"lxml tree build failed, falling back to ElementTree: {lxml_error}")
            
            # Fallback to standard ElementTree
            root = self.parse_xml(xml_content)
            if root is None:
                return None
            
            # Build tree with line numbers
            return self._build_tree_with_line_numbers(xml_content, root)
            
        except Exception as e:
            print(f"Error building XML tree: {e}")
            return None

    def _lxml_element_to_tree_node(self, element, parent_path: str = "", index: int = 1) -> XmlTreeNode:
        """Convert lxml element to tree node using native sourceline"""
        # Determine tag name (handling namespaces)
        tag = element.tag
        if isinstance(tag, str) and tag.startswith("{"):
            tag = tag.split('}', 1)[1]
            
        current_path = f"{parent_path}/{tag}[{index}]" if parent_path else f"/{tag}[{index}]"

        text = element.text.strip() if element.text and element.text.strip() else ""
        
        # Process attributes
        attributes = {}
        if element.attrib:
            for k, v in element.attrib.items():
                # Handle namespaced attributes
                attr_name = k
                if isinstance(k, str) and k.startswith("{"):
                    attr_name = k.split('}', 1)[1]
                attributes[attr_name] = v
                
        attr_string = " ".join([f"{k}=\"{v}\"" for k, v in attributes.items()])
        display_name = tag if not attr_string else f"{tag} [{attr_string}]"

        # lxml provides line number directly
        line_number = getattr(element, 'sourceline', 0) or 0

        node = XmlTreeNode(
            name=display_name,
            tag=tag,
            value=text,
            attributes=attributes,
            path=current_path,
            line_number=line_number
        )

        tag_counts: Dict[str, int] = {}
        for child in element:
            # Get tag name for child (handling namespaces)
            child_tag = child.tag
            if isinstance(child_tag, str) and child_tag.startswith("{"):
                child_tag = child_tag.split('}', 1)[1]
                
            cnt = tag_counts.get(child_tag, 0) + 1
            tag_counts[child_tag] = cnt
            
            # Recursively build children
            child_node = self._lxml_element_to_tree_node(child, current_path, cnt)
            try:
                child_node.parent_node = node
            except Exception:
                pass
            node.children.append(child_node)

        return node

    def _build_tree_with_line_numbers(self, xml_content: str, root: ET.Element) -> XmlTreeNode:
        """Build tree with line numbers from XML content (Legacy/Fallback)"""
        lines = xml_content.split('\n')
        # Quick Win #3: Pre-compute line index for 50-70% faster line number lookups
        line_index = self._build_line_index(lines)
        return self._element_to_tree_node_with_lines(root, lines, "", 0, 1, line_index)

    def _element_to_shallow_node_with_lines(self, element: ET.Element, lines: List[str], parent_path: str = "", start_line: int = 0, index: int = 1, line_index: Optional[Dict[str, List[int]]] = None) -> XmlTreeNode:
        current_path = f"{parent_path}/{element.tag}[{index}]" if parent_path else f"/{element.tag}[{index}]"
        text = element.text.strip() if element.text and element.text.strip() else ""
        attr_string = " ".join([f"{k}=\"{v}\"" for k, v in element.attrib.items()])
        display_name = element.tag if not attr_string else f"{element.tag} [{attr_string}]"
        if line_index is None:
            line_number = 0
        elif element.tag in line_index:
            tag_lines = line_index[element.tag]
            line_number = next((line + 1 for line in tag_lines if line >= start_line), 0)
        else:
            line_number = self._find_element_line_number(lines, element.tag, start_line)
        node = XmlTreeNode(
            name=display_name,
            tag=element.tag,
            value=text,
            attributes=dict(element.attrib),
            path=current_path,
            line_number=line_number
        )
        return node
    
    def _find_element_line_number(self, lines: List[str], tag_name: str, start_line: int = 0) -> int:
        """Find the line number for an XML element"""
        for i in range(start_line, len(lines)):
            line = lines[i].strip()
            # Look for opening tag
            if f"<{tag_name}" in line or f"<{tag_name}>" in line:
                return i + 1  # Convert to 1-based line number
        return 0  # Not found
    
    def _element_to_tree_node(self, element: ET.Element, parent_path: str = "", index: int = 1) -> XmlTreeNode:
        """Convert XML element to tree node (legacy method) with index-aware paths"""
        current_path = f"{parent_path}/{element.tag}[{index}]" if parent_path else f"/{element.tag}[{index}]"

        text = element.text.strip() if element.text and element.text.strip() else ""
        attr_string = " ".join([f"{k}=\"{v}\"" for k, v in element.attrib.items()])
        display_name = element.tag if not attr_string else f"{element.tag} [{attr_string}]"

        node = XmlTreeNode(
            name=display_name,
            tag=element.tag,
            value=text,
            attributes=dict(element.attrib),
            path=current_path,
            line_number=0
        )

        tag_counts: Dict[str, int] = {}
        for child in element:
            cnt = tag_counts.get(child.tag, 0) + 1
            tag_counts[child.tag] = cnt
            child_node = self._element_to_tree_node(child, current_path, cnt)
            try:
                child_node.parent_node = node
            except Exception:
                pass
            node.children.append(child_node)

        return node
    
    def get_element_line_number(self, xml_content: str, element_path: str) -> int:
        """Get line number for specific XML element path"""
        try:
            lines = xml_content.split('\n')
            
            # Simple path parsing - this could be more sophisticated
            path_parts = element_path.split('/')
            current_tag = path_parts[-1] if path_parts else ""
            
            for i, line in enumerate(lines, 1):
                if f"<{current_tag}" in line:
                    return i
            
            return -1
            
        except Exception:
            return -1
    
    def find_elements_by_xpath(self, xml_content: str, xpath: str) -> List[ET.Element]:
        """Find XML elements by XPath (basic implementation)"""
        try:
            root = self.parse_xml(xml_content)
            if root is None:
                return []
            
            # Basic XPath support - this is a simplified implementation
            # For full XPath support, you'd need a proper XPath library
            
            if xpath.startswith('//'):
                # Find all elements with this tag
                tag_name = xpath[2:]
                return root.findall(f".//{tag_name}")
            elif xpath.startswith('/'):
                # Absolute path
                tag_name = xpath[1:]
                return root.findall(f"./{tag_name}")
            else:
                # Relative path
                return root.findall(xpath)
                
        except Exception as e:
            print(f"Error finding elements by XPath: {e}")
            return []
    
    def get_xml_statistics(self, xml_content: str) -> XmlStatistics:
        """Get XML statistics"""
        try:
            root = self.parse_xml(xml_content)
            if root is None:
                return XmlStatistics(0, 0, 0, 0, 0)
            
            element_count = 0
            attribute_count = 0
            text_node_count = 0
            comment_count = 0
            
            def count_elements(element: ET.Element):
                nonlocal element_count, attribute_count, text_node_count
                
                element_count += 1
                attribute_count += len(element.attrib)
                
                if element.text and element.text.strip():
                    text_node_count += 1
                
                for child in element:
                    count_elements(child)
            
            count_elements(root)
            
            # Count comments manually
            comment_pattern = r'<!--.*?-->'
            comments = re.findall(comment_pattern, xml_content, re.DOTALL)
            comment_count = len(comments)
            
            total_size = len(xml_content.encode('utf-8'))
            
            return XmlStatistics(
                element_count=element_count,
                attribute_count=attribute_count,
                text_node_count=text_node_count,
                comment_count=comment_count,
                total_size=total_size
            )
            
        except Exception as e:
            print(f"Error getting XML statistics: {e}")
            return XmlStatistics(0, 0, 0, 0, 0)
    
    def set_namespace(self, prefix: str, uri: str):
        """Set namespace for XPath queries"""
        self.namespaces[prefix] = uri
    
    def clear_namespaces(self):
        """Clear all namespaces"""
        self.namespaces.clear()
    
    def create_split_config(self, threshold_percentage: float = 15.0, upper_levels: list = None) -> XmlSplitConfig:
        """Create a default split configuration with threshold-based rules"""
        if upper_levels is None:
            upper_levels = [2, 3]
        
        config = XmlSplitConfig(
            threshold_percentage=threshold_percentage,
            upper_levels=upper_levels
        )
        return config
    
    def analyze_xml_for_splitting(self, xml_content: str, config: XmlSplitConfig = None) -> dict:
        """Analyze XML content to determine optimal splitting strategy"""
        if config is None:
            config = self.create_split_config()
        
        splitter = XmlSplitter(config)
        return splitter.analyze_xml_structure(xml_content)
    
    def split_xml_content(self, xml_content: str, output_dir: str, config: XmlSplitConfig = None) -> bool:
        """Split XML content into manageable parts"""
        try:
            if config is None:
                config = self.create_split_config()
            
            splitter = XmlSplitter(config)
            metadata = splitter.split_xml(xml_content, output_dir)
            
            return metadata is not None
            
        except Exception as e:
            print(f"Error splitting XML: {e}")
            return False
    
    def load_split_project(self, split_directory: str) -> XmlPartManager:
        """Load an existing split XML project"""
        return XmlPartManager(split_directory)
    
    def reconstruct_xml_from_parts(self, split_directory: str) -> str:
        """Reconstruct complete XML from split parts"""
        part_manager = XmlPartManager(split_directory)
        return part_manager.reconstruct_xml()
    
    def validate_split_project(self, split_directory: str) -> dict:
        """Validate all parts in a split project"""
        part_manager = XmlPartManager(split_directory)
        return part_manager.validate_parts()
    
    def get_split_project_info(self, split_directory: str) -> dict:
        """Get information about a split project"""
        part_manager = XmlPartManager(split_directory)
        if part_manager.is_split_project():
            return {
                'is_valid': True,
                'statistics': part_manager.get_part_statistics(),
                'parts': part_manager.get_part_list(),
                'dependencies': part_manager.get_dependencies()
            }
        else:
            return {'is_valid': False}
    
    def search_in_split_project(self, split_directory: str, search_term: str, case_sensitive: bool = False) -> list:
        """Search for content across all parts in a split project"""
        part_manager = XmlPartManager(split_directory)
        return part_manager.search_in_parts(search_term, case_sensitive)
    
    def auto_close_tags(self, xml_content: str) -> str:
        """Auto-close unclosed tags by the shortest path.
        
        This method analyzes the XML content and automatically closes any unclosed tags
        by finding the shortest path to close them properly.
        
        Args:
            xml_content: The XML content string that may have unclosed tags
            
        Returns:
            The XML content with all tags properly closed
        """
        try:
            # First try to parse - if it works, no need to fix
            try:
                ET.fromstring(xml_content)
                return xml_content  # Already valid
            except ET.ParseError:
                pass  # Need to fix
            
            lines = xml_content.split('\n')
            tag_stack = []  # Stack of (tag_name, line_index, indent_level)
            result_lines = []
            
            # Track self-closing tags pattern
            self_closing_pattern = re.compile(r'<([a-zA-Z_][a-zA-Z0-9_:-]*)[^>]*/>')
            
            for line_idx, line in enumerate(lines):
                result_lines.append(line)
                
                # Calculate indent level
                indent_level = len(line) - len(line.lstrip())
                
                # Find all self-closing tags and skip them
                self_closing_tags = self_closing_pattern.findall(line)
                
                # Find opening tags (excluding self-closing and closing tags)
                opening_pattern = re.compile(r'<([a-zA-Z_][a-zA-Z0-9_:-]*)[^/>]*>')
                opening_tags = opening_pattern.findall(line)
                
                # Find closing tags
                closing_pattern = re.compile(r'</([a-zA-Z_][a-zA-Z0-9_:-]*)>')
                closing_tags = closing_pattern.findall(line)
                
                # Process opening tags
                for tag in opening_tags:
                    # Skip if this tag is self-closing on this line
                    if tag not in self_closing_tags:
                        # Check if there's a closing tag on the same line
                        if tag not in closing_tags or closing_tags.count(tag) < opening_tags.count(tag):
                            tag_stack.append((tag, line_idx, indent_level))
                
                # Process closing tags
                for tag in closing_tags:
                    if tag_stack and tag_stack[-1][0] == tag:
                        tag_stack.pop()
                    elif tag_stack:
                        # Mismatched closing tag - try to find matching opening tag
                        for i in range(len(tag_stack) - 1, -1, -1):
                            if tag_stack[i][0] == tag:
                                # Close all tags between current position and matching tag
                                tags_to_close = []
                                while len(tag_stack) > i:
                                    tags_to_close.append(tag_stack.pop())
                                # Re-open tags that were closed prematurely (except the matched one)
                                for j in range(len(tags_to_close) - 2, -1, -1):
                                    tag_stack.append(tags_to_close[j])
                                break
            
            # Close any remaining unclosed tags by shortest path
            if tag_stack:
                # Get the indent of the last line
                last_line = result_lines[-1] if result_lines else ""
                base_indent = len(last_line) - len(last_line.lstrip())
                
                # Close tags in reverse order (LIFO - Last In First Out)
                while tag_stack:
                    tag_name, _, tag_indent = tag_stack.pop()
                    # Use the tag's original indent level for closing
                    indent = " " * tag_indent
                    result_lines.append(f"{indent}</{tag_name}>")
            
            return '\n'.join(result_lines)
            
        except Exception as e:
            print(f"Error in auto_close_tags: {e}")
            return xml_content  # Return original on error